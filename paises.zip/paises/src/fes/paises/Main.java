package fes.paises;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Main {
	String imagen;
    public static void main(String[] args) {
    	JButton b = new JButton("Actualizar Imagenes");
    	JButton b2 = new JButton("Actualizar este dato");
    	Contenedor contenedor = new Contenedor(b,b2);
    	b.addActionListener(contenedor);
    	b2.addActionListener(contenedor);
    	
    	
        JPanel container = new JPanel();
        container.setLayout(new BoxLayout(container, BoxLayout.X_AXIS));
        JPanel containerHoriz1 = new JPanel();
        containerHoriz1.setLayout(new BoxLayout(containerHoriz1, BoxLayout.Y_AXIS));
        containerHoriz1.add(new Alta());
        Imagen img = contenedor.imagen;
        img.setSize(35,35);
        containerHoriz1.add(img);

        JPanel containerHoriz2 = new JPanel();
        containerHoriz2.setLayout(new BoxLayout(containerHoriz2, BoxLayout.Y_AXIS));
        Elementos ele = contenedor.elementos;
        containerHoriz2.add(ele);
        containerHoriz2.add(contenedor.editor);

        container.add(containerHoriz1);
        container.add(containerHoriz2);

        JFrame frame = new JFrame("Paises");
        frame.setContentPane(container);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(900,700);
        frame.setVisible(true);
    }
}