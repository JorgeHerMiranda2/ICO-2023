package fes.paises;
import java.awt.event.ActionListener;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.util.ArrayList;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;
import javax.swing.JButton;
import javax.swing.JPanel;
public class Elementos extends App{
	JTable tabla;
	String[] columnas= {"Id","Nombre","Continente","imagen","poblacion","pib"};
	JButton actualizar=new JButton("Actualizar Tabla");
	Object[][] datos;
	JPanel cont;
	
	public Elementos(JButton b,JButton b2) {
        Connection connection = null;
		try {
	          connection = DriverManager.getConnection("jdbc:sqlite:paises.db");
	          Statement statement = connection.createStatement();
	          statement.setQueryTimeout(30);

	          ResultSet rs = statement.executeQuery("select * from paises");
	          int cantidad=0;
	          while(rs.next())
	          {
	        	  cantidad +=1;
	          }
	          datos= new Object[cantidad][6];

	          rs = statement.executeQuery("select * from paises");
	          int indice=0;
	          while(rs.next())
	          {
	        	ArrayList<Object> lista = new ArrayList();
	          	lista.add(rs.getInt("id"));
	          	lista.add(rs.getString("nombre"));
	          	lista.add(rs.getString("continente"));
	          	lista.add(rs.getString("imagen"));
	          	lista.add(rs.getInt("poblacion"));
	          	lista.add(rs.getFloat("pib"));
	          	datos[indice]= lista.toArray();
	        	indice +=1;
	          }

			
		}catch(SQLException e) {
			
		}
        	tabla = new JTable(datos,columnas);
		cont=new JPanel();
		JScrollPane s = new JScrollPane(tabla);
		cont.add(s);
		this.add(actualizar);
		this.add(b);
		this.add(b2);
		actualizar.addActionListener(this);
		this.add(cont);
	}

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==actualizar) {
        	actualizar();
        }
    }
    
    public void actualizar() {
        Connection connection = null;
        cont=new JPanel();
		try {
	          connection = DriverManager.getConnection("jdbc:sqlite:paises.db");
	          Statement statement = connection.createStatement();
	          statement.setQueryTimeout(30);

	          ResultSet rs = statement.executeQuery("select * from paises");
	          int cantidad=0;
	          while(rs.next())
	          {
	        	  cantidad +=1;
	          }

	          rs = statement.executeQuery("select * from paises");
	          int indice=0;
	          TableModel model = tabla.getModel();
	          if (model.getRowCount()!=cantidad) {
	        	    DefaultTableModel modelo = new DefaultTableModel();
	        	    datos= new Object[cantidad][6];
	        	    for (String str:columnas)
	        		  modelo.addColumn(str);

	        	  	while(rs.next())
	        	  		{
	        	  		ArrayList<Object> lista = new ArrayList();
	        	  		lista.add(rs.getInt("id"));
	        	  		lista.add(rs.getString("nombre"));
	        	  		lista.add(rs.getString("continente"));
	        	  		lista.add(rs.getString("imagen"));
	        	  		lista.add(rs.getInt("poblacion"));
	        	  		lista.add(rs.getFloat("pib"));
	        	  		datos[indice]= lista.toArray();
	        	  		modelo.addRow(lista.toArray());
	        	  		indice +=1;
	        	  		}

	        	  tabla.setModel(modelo);
	        	  return;
	          }
	          while(rs.next())
	          {
	        	model.setValueAt(rs.getInt("id"), indice, 0);
	        	model.setValueAt(rs.getString("nombre"), indice, 1);
	        	model.setValueAt(rs.getString("continente"), indice, 2);
	        	model.setValueAt(rs.getString("imagen"), indice, 3);
	        	model.setValueAt(rs.getInt("poblacion"), indice, 4);
	        	model.setValueAt(rs.getFloat("pib"), indice, 5);
	        	indice +=1;
	          }
		}catch(SQLException e) {
			
		}
    }	
    
    public String getImagen() {
        	int num = tabla.getSelectedRow();
        	if (num!=-1) {
        		String img = (String) datos[num][3];
        		return img;
    			}
    	return "";
    }

    public Pais getEditar() {
        	int num = tabla.getSelectedRow();
        	if (num!=-1) {
        		int id = (int) datos[num][0];
        		String nombre = (String) datos[num][1];
        		String continente = (String) datos[num][2];
        		String img = (String) datos[num][3];
        		int poblacion = (int) datos[num][4];
        		float pib = (float) datos[num][5];
        		return new Pais(id,nombre,continente,img,poblacion,pib);
    			}
    	return null;
    }
    
    public void actualizarDB(Pais pais) {
        Connection connection = null;
        cont=new JPanel();
		try {
	          connection = DriverManager.getConnection("jdbc:sqlite:paises.db");
	          Statement statement = connection.createStatement();
	          statement.setQueryTimeout(30);
	          String str=
	        "nombre= '"+pais.nombre+"',continente='"+pais.continente+"', imagen= '"+pais.imagen+"', pib="+pais.pib+", poblacion="+pais.poblacion+"";
	          ResultSet rs = statement.executeQuery("update paises set "+str+" where id="+pais.id);
		}catch(SQLException e) {
			
		}
    	
    }

}
