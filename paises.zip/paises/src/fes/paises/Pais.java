package fes.paises;

public class Pais {
int id;
String nombre;
String continente;
String imagen;
int poblacion;
float pib;

	Pais(int id, String nombre, String continente,String imagen, int poblacion, float pib){
		this.id =id;
		this.nombre = nombre;
		this.continente = continente;
		this.imagen = imagen;
		this.poblacion=poblacion;
		this.pib=pib;
	}
}
