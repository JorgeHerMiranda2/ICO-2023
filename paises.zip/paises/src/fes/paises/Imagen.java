package fes.paises;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Imagen extends App{
	Image newImage;
	JLabel label;

	public Imagen() {
		String path = "https://upload.wikimedia.org/wikipedia/commons/thumb/7/76/Bandera_de_M%C3%A9xico_%281934-1968%29.png/1200px-Bandera_de_M%C3%A9xico_%281934-1968%29.png";
	    try {
			URL url = new URL(path);
			BufferedImage image = ImageIO.read(url);
			newImage = image.getScaledInstance(250, 250, image.SCALE_DEFAULT);
		    label = new JLabel(new ImageIcon(newImage));
		    label.setSize(35, 35);
		    this.add(label);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void actualizar(String str) {
		if (str=="")return;
	    try {
			URL url = new URL(str);
			BufferedImage image = ImageIO.read(url);
			newImage = image.getScaledInstance(250, 250, image.SCALE_DEFAULT);
			label.setIcon(new ImageIcon(newImage));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
