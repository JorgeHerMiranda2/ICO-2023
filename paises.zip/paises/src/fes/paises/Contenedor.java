package fes.paises;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class Contenedor implements ActionListener {
	public Elementos elementos;
	public Imagen imagen;
	public Editor editor;
	JButton B2;
	JButton B3;
	
	public Contenedor(JButton b, JButton b2) {
		elementos=new Elementos(b,b2);
		B3=new JButton("Actualizar");
		B3.addActionListener(this);
		imagen=new Imagen();
		editor=new Editor(B3);
		B2=b2;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==B2) {
			editor.editarElemento(elementos.getEditar());
			return;
		}
		if (e.getSource()==B3) {
			elementos.actualizarDB(editor.getElemento());
			return;
		}
        		imagen.actualizar(elementos.getImagen());
	}

}
