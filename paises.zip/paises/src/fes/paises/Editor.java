package fes.paises;

import java.awt.Dimension;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Editor extends App{
	int Id;
    JTextArea nombre = new JTextArea();
    JLabel nombreL = new JLabel("Actualizar nombre");
    JTextArea imagen = new JTextArea();
    JLabel imagenL = new JLabel("Actualizar la imagen");
    JTextArea continente = new JTextArea();
    JLabel continenteL = new JLabel("Actualizar continente");
    JTextArea poblacion = new JTextArea();
    JLabel poblacionL = new JLabel("Actualizar poblacion:");
    JTextArea pib = new JTextArea();
    JLabel pibL = new JLabel("Ingrese el pib:");
    
    Editor(JButton b3){
        JPanel container = new JPanel();
        imagen.setColumns(4);
        nombre.setMaximumSize(new Dimension(200,100));
        imagen.setMaximumSize(new Dimension(200,100));
        continente.setMaximumSize(new Dimension(200,100));
        poblacion.setMaximumSize(new Dimension(200,100));
        pib.setMaximumSize(new Dimension(200,100));
        imagen.setMaximumSize(new Dimension(200,100));
        container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
    	container.add(nombreL);
    	container.add(nombre);

    	container.add(imagenL);
    	container.add(imagen);

    	container.add(continenteL);
    	container.add(continente);

    	container.add(poblacionL);
    	container.add(poblacion);

    	container.add(pibL);
    	container.add(pib);
    	container.add(b3);
    	
        this.add(container);
    }

	public void editarElemento(Pais editar) {
		if (editar==null)return;
		nombre.setText(editar.nombre);
		imagen.setText(editar.imagen);
		continente.setText(editar.continente);
		poblacion.setText(""+editar.poblacion);
		pib.setText(""+editar.pib);
		Id=editar.id;
	}

	public Pais getElemento() {
		//Pais p =new Pais(Id,nombre.getText(),imagen.getText(),continente.getText(),Integer.parseInt(poblacion.getText()),
		Pais p =new Pais(Id,nombre.getText(),continente.getText(),imagen.getText(),Integer.parseInt(poblacion.getText()),
				Float.parseFloat(pib.getText()));
		nombre.setText("");
		imagen.setText("");
		continente.setText("");
		poblacion.setText("");
		pib.setText("");
		return p;
	}

}
