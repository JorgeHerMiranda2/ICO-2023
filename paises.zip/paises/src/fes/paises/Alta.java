package fes.paises;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.awt.event.ActionListener;

public class Alta extends App {
    //JTextArea id = new JTextArea(20);
    JTextArea nombre = new JTextArea();
    JLabel nombreL = new JLabel("Ingrese el Nombre");
    JTextArea imagen = new JTextArea();
    JLabel imagenL = new JLabel("Ingrese la imagen");
    JTextArea continente = new JTextArea();
    JLabel continenteL = new JLabel("Ingrese el continente");
    JTextArea poblacion = new JTextArea();
    JLabel poblacionL = new JLabel("Ingrese la poblacion:");
    JTextArea pib = new JTextArea();
    JLabel pibL = new JLabel("Ingrese el pib:");
    JButton añadir=new JButton("Añadir");
    public Alta(){
        JPanel container = new JPanel();
        container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));

        container.add(nombreL);
        container.add(nombre);

        container.add(imagenL);
        container.add(imagen);

        container.add(poblacionL);
        container.add(poblacion);

        container.add(continenteL);
        container.add(continente);

        container.add(pibL);
        container.add(pib);

        container.add(añadir);
        añadir.addActionListener(this);

        this.add(container);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==añadir) {
        	Añadir();
        }
    }
    
    public void Añadir() {
        Connection connection = null;
		try {
	          connection = DriverManager.getConnection("jdbc:sqlite:paises.db");
	          Statement statement = connection.createStatement();
	          int pob=Integer.parseInt(poblacion.getText());
	          float pibV=Float.parseFloat(pib.getText());
	          statement.setQueryTimeout(30);
	          ResultSet rs = statement.executeQuery("select * from paises");
	          int indice=0;
	          while(rs.next())
	          {
	        	indice +=1;
	          }
	        	indice +=1;
	          statement.executeUpdate("insert into paises values("+indice+", '"+
	          nombre.getText()+"','"+imagen.getText()+"',"+
	          pob+", '"+continente.getText()+"',"+pibV+")");
	          nombre.setText("");
	          imagen.setText("");
	          poblacion.setText("");
	          pib.setText("");
	          continente.setText("");
		}catch(Exception e) {
			
		}

    }
}
