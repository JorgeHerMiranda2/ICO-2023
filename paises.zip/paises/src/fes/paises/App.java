package fes.paises;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.ActionListener;

import static java.awt.event.KeyEvent.*;

public class App extends JPanel implements ActionListener{
    @Override
    public void actionPerformed(ActionEvent e) {
    }
}
